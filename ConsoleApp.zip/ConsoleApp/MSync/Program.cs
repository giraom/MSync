﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Threading;

namespace MSync
{
    class Program
    {
        static void Main(string[] args)
        {
            string str_subscriber = string.Empty;
            Int32 threads = 4;
            Int32 priorityGroup = 0;
            Int32 subscriptionId = 0;
            Int32 batchSize = 1000;

            if (args.Length == 0)
            {
                str_subscriber = "Data Source=cmsdemoazuresql.database.windows.net;Initial Catalog=PersonDb;User Id=MSync;Application Name=MSync;";
                subscriptionId = 0;
                threads = 1;
                priorityGroup = 0;
            }
            else if (args.Length == 1)
            {
                str_subscriber = args[0];
            }
            else if (args.Length == 2)
            {
                str_subscriber = args[0];
                threads = Int32.Parse(args[1]);
            }
            else if (args.Length == 3)
            {
                str_subscriber = args[0];
                threads = Int32.Parse(args[1]);
                priorityGroup = Int32.Parse(args[2]);
            }
            else if (args.Length == 4)
            {
                str_subscriber = args[0];
                threads = Int32.Parse(args[1]);
                priorityGroup = Int32.Parse(args[2]);
                subscriptionId = Int32.Parse(args[3]);
            }
            else if (args.Length == 5)
            {
                str_subscriber = args[0];
                threads = Int32.Parse(args[1]);
                priorityGroup = Int32.Parse(args[2]);
                subscriptionId = Int32.Parse(args[3]);
                batchSize = Int32.Parse(args[4]);
            }

            var repClass = new ReplicateClass();
            string message = string.Empty;

            try
            {
                if (str_subscriber.Contains("User Id=MSync;"))
                {
                    String[] arr_subscriber = str_subscriber.Split(';');
                    str_subscriber = arr_subscriber[0] + ";" + arr_subscriber[1] + ";" + arr_subscriber[2] + ";" + "Password=VisitBr@z1l;";
                }
                if (!(str_subscriber.Contains("Application Name")))
                {
                    str_subscriber += "Application Name=MSync;";
                }
                message = repClass.Replicate(str_subscriber, threads, priorityGroup, subscriptionId, batchSize).ToString();
            }
            catch (Exception ex)
            {
                message += (ex.Message);
            }
            Console.WriteLine(message);
            // Console.ReadKey();
        }
    }

    public class ReplicateClass
    {
        public static bool varsuccess = true;
        public static bool useStage = true;
        public string shortMessage;
        public StringBuilder detailMessage = new StringBuilder();

        public string Replicate(string str_subscriber, int threads, int priorityGroup, int subscriptionId, int batchSize)
        {
            var tpl = new Tuple<string, Int64>(string.Empty, 0);
            string rvto = string.Empty;
            string rvfrom = string.Empty;
            Int64 rvTotalRows = 0;
            string str_publisher = string.Empty;
            bool initialize = false;
            string method = string.Empty;
            string mergeIdentifier = string.Empty;

            SqlConnection conn_subscriber = new SqlConnection(str_subscriber);
            SqlConnection conn_subscriber_loop = new SqlConnection(str_subscriber);

            //open connection to subscriber
            try
            {
                conn_subscriber.Open();
                conn_subscriber_loop.Open();

                SqlCommand SubscriptionsCommand = new SqlCommand("exec rpl.spGetSubscriptions " + priorityGroup.ToString() + ", " + subscriptionId.ToString(), conn_subscriber_loop);
                SqlDataReader SubscriptionsReader = SubscriptionsCommand.ExecuteReader();
                while (SubscriptionsReader.Read())
                {
                    try
                    {
                        //initialize control variables
                        varsuccess = true;
                        useStage = true;
                        shortMessage = string.Empty;
                        detailMessage.Clear();
                        rvto = string.Empty;
                        rvfrom = string.Empty;
                        rvTotalRows = 0;

                        //get Subscription values
                        str_publisher = SubscriptionsReader["ConnectionString"].ToString();
                        subscriptionId = Convert.ToInt32(SubscriptionsReader["subscriptionId"]);
                        initialize = Convert.ToBoolean(SubscriptionsReader["Initialize"]);
                        mergeIdentifier = Convert.ToString(SubscriptionsReader["MergeIdentifier"]);

                        if (!(str_publisher.Contains("Application Name")))
                        {
                            str_publisher += "Application Name=MSync;";
                        }
                        SqlConnection conn_publisher = new SqlConnection(str_publisher);

                        //main replication block
                        try
                        {
                            //open connection to str_publisher
                            try
                            {
                                method = "conn_publisher.Open";
                                conn_publisher.Open();

                                //Get Subscription Timestamp to be used as end boundary. During a load new data may be entering the Subscription database, however we will replicate only up to this point.
                                method = "GetSubscriptionTimestamp";
                                rvto = GetSubscriptionTimestamp(conn_publisher);

                                //Log start to entry 
                                method = "Start";
                                tpl = Start(conn_subscriber, rvto, subscriptionId, threads);

                                rvfrom = tpl.Item1;
                                rvTotalRows = tpl.Item2;

                                if (rvfrom == "")
                                {
                                    rvfrom = "0x";
                                }

                                if ((rvfrom == "0x") && (!initialize) && (String.IsNullOrEmpty(mergeIdentifier)))
                                {
                                    throw new Exception("There is no history for subscriptionid " + subscriptionId.ToString() + ", but the subscription is not set to initialize. The process was aborted. If you are sure you want to initialize the subscriber please run 'update rpl.Subscription set Initialize =1 where subscriptionid = ?' and re run.");
                                }

                                //if loading for the first time we clean up all replicated tables in prod schema.
                                if (initialize)
                                {
                                    useStage = false;
                                    method = "DisableIndexes";
                                    DisableIndexes(conn_subscriber, subscriptionId);
                                    method = "CleanProdTables";
                                    CleanProdTables(str_subscriber, subscriptionId, "");
                                }

                                //Clean up tables in stage
                                method = "TruncateStage";
                                TruncateStage(conn_subscriber, subscriptionId);

                                //Performs the load only if there was data movement on the Subscription since last replication, although movement may have occurred on a non replicated table.
                                if (string.Compare(rvto, rvfrom) > 0)
                                {
                                    //Disable Constraints to allow for parallel load with no concern for FKs
                                    method = "DisableConstraints";
                                    DisableConstraints(conn_subscriber, subscriptionId);

                                    //Perform bulk copy phase
                                    method = "CopyToStage";
                                    CopyToStage(str_publisher, str_subscriber, rvfrom, rvto, subscriptionId, threads, batchSize, mergeIdentifier);

                                    //initial load copies directly into production schemas, incremental loads copy to stage tables then merge to prod. 
                                    if ((useStage) && (varsuccess))
                                    {
                                        method = "MergeData";
                                        MergeData(str_subscriber, subscriptionId, threads);
                                    }

                                    if ((rvfrom == "0x") || (initialize))
                                    {
                                        method = "EnableIndexes";
                                        EnableIndexes(str_subscriber, subscriptionId, threads);
                                    }

                                    method = "RunRoutines";
                                    RunRoutines(str_subscriber, rvfrom, rvto, subscriptionId);

                                    //Enable constraints back
                                    method = "EnableConstraints";
                                    EnableConstraints(conn_subscriber, subscriptionId);
                                }
                                else
                                {
                                    shortMessage = shortMessage + "No data found.";
                                    detailMessage.AppendLine("No data found.");
                                }
                            }
                            catch (Exception ex)
                            {
                                detailMessage.AppendLine("Error connecting to " + str_publisher);
                                detailMessage.AppendLine(ex.Message);
                                varsuccess = false;
                                throw ex;
                            }
                            finally
                            {
                                conn_publisher.Dispose();
                                SqlConnection.ClearPool(conn_publisher);
                            }


                        }
                        catch (Exception ex)
                        {
                            shortMessage = method + " " + shortMessage;
                            detailMessage.AppendLine(method);
                            detailMessage.AppendLine(ex.Message);
                            varsuccess = false;
                            throw ex;
                        }
                        finally
                        {
                            End(conn_subscriber, detailMessage.ToString(), varsuccess, subscriptionId);
                        }

                    }
                    catch (Exception ex)
                    {
                        detailMessage.AppendLine("Error running subscription " + subscriptionId.ToString());
                        detailMessage.AppendLine(ex.Message);
                    }
                }

            }
            catch (Exception ex)
            {
                detailMessage.AppendLine("Error connecting to subscriber.");
                detailMessage.AppendLine(ex.Message);
                varsuccess = false;
                throw ex;
            }
            finally
            {
                conn_subscriber.Dispose();
                SqlConnection.ClearPool(conn_subscriber);

                conn_subscriber_loop.Dispose();
                SqlConnection.ClearPool(conn_subscriber_loop);
            }
            return detailMessage.ToString();
        }

        protected Tuple<string, Int64> Start(SqlConnection conn_subscriber, string rvto, int subscriptionId, int threads)
        {
            SqlCommand cmd = new SqlCommand(@"rpl.spStart", conn_subscriber);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            SqlParameter param_subscriptionId = new SqlParameter("@SubscriptionId", SqlDbType.Int);
            param_subscriptionId.Value = subscriptionId;
            param_subscriptionId.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(param_subscriptionId);

            SqlParameter param_threads = new SqlParameter("@Threads", SqlDbType.Int);
            param_threads.Value = threads;
            param_threads.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(param_threads);

            SqlParameter param_rvfrom = new SqlParameter("@rvfrom", SqlDbType.VarChar, 20);
            param_rvfrom.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(param_rvfrom);

            SqlParameter param_rvto = new SqlParameter("@rvto", SqlDbType.VarChar, 20);
            param_rvto.Direction = ParameterDirection.Input;
            param_rvto.Value = rvto;
            cmd.Parameters.Add(param_rvto);

            SqlParameter param_RvTotalRows = new SqlParameter("@RvTotalRows", SqlDbType.BigInt);
            param_RvTotalRows.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(param_RvTotalRows);

            cmd.ExecuteNonQuery();

            return Tuple.Create(cmd.Parameters["@rvfrom"].Value.ToString(), (Int64)cmd.Parameters["@RvTotalRows"].Value);
        }

        protected void End(SqlConnection conn_subscriber, string message, Boolean success, int subscriptionId)
        {
            SqlCommand cmd = new SqlCommand(@"rpl.spEnd", conn_subscriber);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlParameter param_subscriptionId = new SqlParameter("@subscriptionId", SqlDbType.Int);
            param_subscriptionId.Value = subscriptionId;
            param_subscriptionId.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(param_subscriptionId);

            SqlParameter param_message = new SqlParameter("@message", SqlDbType.VarChar, 8000);
            param_message.Direction = ParameterDirection.Input;
            param_message.Value = message;
            cmd.Parameters.Add(param_message);

            SqlParameter param_TotalRows = new SqlParameter("@TotalRows", SqlDbType.BigInt);
            param_TotalRows.Direction = ParameterDirection.Output;
            //param_TotalRows.Value = rowcount;
            cmd.Parameters.Add(param_TotalRows);

            SqlParameter param_success = new SqlParameter("@success", SqlDbType.Bit);
            param_success.Direction = ParameterDirection.Input;
            param_success.Value = success;
            cmd.Parameters.Add(param_success);

            cmd.ExecuteNonQuery();
        }

        protected string GetSubscriptionTimestamp(SqlConnection conn_publisher)
        {
            SqlCommand cmd = new SqlCommand(@"rpl.spGetCurrentTimestamp", conn_publisher);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlParameter param_rvto = new SqlParameter("@rv", SqlDbType.VarChar, 20);
            param_rvto.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(param_rvto);

            cmd.ExecuteNonQuery();

            return (cmd.Parameters["@rv"].Value.ToString());
        }

        protected void TruncateStage(SqlConnection conn_subscriber, int subscriptionId)
        {
            SqlCommand cmd = new SqlCommand(@"rpl.spTruncateStage", conn_subscriber);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlParameter param_subscriptionId = new SqlParameter("@subscriptionId", SqlDbType.Int);
            param_subscriptionId.Value = subscriptionId;
            param_subscriptionId.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(param_subscriptionId);

            cmd.CommandTimeout = 900;
            cmd.ExecuteNonQuery();
        }

        protected void DisableConstraints(SqlConnection conn_subscriber, int subscriptionId)
        {
            SqlCommand cmd = new SqlCommand(@"rpl.spDisableConstraints", conn_subscriber);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlParameter param_subscriptionId = new SqlParameter("@SubscriptionId", SqlDbType.Int);
            param_subscriptionId.Value = subscriptionId;
            param_subscriptionId.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(param_subscriptionId);

            cmd.CommandTimeout = 900;
            cmd.ExecuteNonQuery();
        }

        protected void DisableIndexes(SqlConnection conn_subscriber, int subscriptionId)
        {
            SqlCommand cmd = new SqlCommand(@"rpl.spDisableIndexes", conn_subscriber);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlParameter param_subscriptionId = new SqlParameter("@SubscriptionId", SqlDbType.Int);
            param_subscriptionId.Value = subscriptionId;
            param_subscriptionId.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(param_subscriptionId);

            cmd.CommandTimeout = 900;
            cmd.ExecuteNonQuery();
        }


        protected void EnableConstraints(SqlConnection conn_subscriber, int subscriptionId)
        {
            SqlCommand cmd = new SqlCommand(@"rpl.spEnableConstraints", conn_subscriber);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlParameter param_subscriptionId = new SqlParameter("@subscriptionId", SqlDbType.Int);
            param_subscriptionId.Value = subscriptionId;
            param_subscriptionId.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(param_subscriptionId);

            cmd.CommandTimeout = 900;
            cmd.ExecuteNonQuery();
        }

        protected void RunRoutines(string str_subscriber, string rvfrom, string rvto, int subscriptionId)
        {
            SqlConnection conn_subscriber = new SqlConnection(str_subscriber);
            SqlConnection conn_subscriber_routine = new SqlConnection(str_subscriber);
            string routineName = string.Empty;

            try
            {
                conn_subscriber.Open();
                conn_subscriber_routine.Open();

                SqlCommand cmd = new SqlCommand("exec rpl.spGetRoutineList @SubscriptionId = " + subscriptionId.ToString(), conn_subscriber);
                cmd.CommandType = CommandType.Text;

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    routineName = reader["RoutineName"].ToString();
                    SqlCommand routine = new SqlCommand(routineName, conn_subscriber_routine);
                    routine.CommandType = CommandType.StoredProcedure;
                    routine.CommandTimeout = 2700;

                    SqlParameter param_subscriptionId = new SqlParameter("@subscriptionId", SqlDbType.VarChar, 20);
                    param_subscriptionId.Direction = ParameterDirection.Input;
                    param_subscriptionId.Value = subscriptionId;
                    routine.Parameters.Add(param_subscriptionId);

                    SqlParameter param_rvfrom = new SqlParameter("@rvfrom", SqlDbType.VarChar, 20);
                    param_rvfrom.Direction = ParameterDirection.Input;
                    param_rvfrom.Value = rvfrom;
                    routine.Parameters.Add(param_rvfrom);

                    SqlParameter param_rvto = new SqlParameter("@rvto", SqlDbType.VarChar, 20);
                    param_rvto.Direction = ParameterDirection.Input;
                    param_rvto.Value = rvto;
                    routine.Parameters.Add(param_rvto);

                    routine.ExecuteNonQuery();
                }
                reader.Close();
                conn_subscriber.Close();
                conn_subscriber_routine.Close();
            }
            catch (Exception ex)
            {
                varsuccess = false;
                shortMessage += "/ Error executing routine " + routineName;
                detailMessage.AppendLine(routineName + "-" + ex.Message);
                throw;
            }
            finally
            {
                conn_subscriber.Close();
                conn_subscriber_routine.Close();
            }
        }

        protected List<string> GetTableList(string str_subscriber, int subscriptionId)
        {
            SqlConnection conn_subscriber = new SqlConnection(str_subscriber);
            SqlDataAdapter adapter = new SqlDataAdapter();
            DataSet ds = new DataSet();
            string table = String.Empty;
            List<string> list = new List<string>();

            try
            {
                conn_subscriber.Open();
                SqlCommand cmd = new SqlCommand("exec rpl.spGetTableList @SubscriptionId = " + subscriptionId.ToString(), conn_subscriber);
                cmd.CommandType = CommandType.Text;
                adapter.SelectCommand = cmd;
                adapter.Fill(ds);
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    table = "[" + Convert.ToString(dr["SchemaName"] + "].[" + dr["TableName"]) + "]";
                    if (Convert.ToBoolean(dr["Initialize"]) && String.IsNullOrEmpty(dr["MergeIdentifier"].ToString())) //table is market to initialize and is not part of merge replication
                    {
                        table += "#Initialize";
                    }
                    list.Add(table);
                }
            }
            catch (Exception ex)
            {
                varsuccess = false;
                shortMessage += "/ Error getting table list";
                detailMessage.AppendLine(ex.Message);
                throw;
            }
            finally
            {
                conn_subscriber.Close();
            }
            return (list);
        }

        protected void CopyToStage(string str_publisher, string str_subscriber, string rvfrom, string rvto, int subscriptionId, int threads, int batchSize, string mergeIdentifier)
        {
            var tables = GetTableList(str_subscriber, subscriptionId);
            Parallel.ForEach(
                tables,
                new ParallelOptions { MaxDegreeOfParallelism = threads },
                (tablename) =>
                {
                    CopyToStageTable(str_publisher, str_subscriber, rvfrom, rvto, tablename, subscriptionId, batchSize, mergeIdentifier);
                });
        }

        protected void MergeData(string str_subscriber, int subscriptionId, int threads)
        {
            var tables = GetTableList(str_subscriber, subscriptionId);
            Parallel.ForEach(
                tables,
                new ParallelOptions { MaxDegreeOfParallelism = threads },
                (tablename) =>
                {
                    MergeTable(str_subscriber, tablename);
                });
        }

        protected void EnableIndexes(string str_subscriber, int subscriptionId, int threads)
        {
            var tables = GetTableList(str_subscriber, subscriptionId);
            Parallel.ForEach(
                tables,
                new ParallelOptions { MaxDegreeOfParallelism = threads },
                (tablename) =>
                {
                    EnableIndexesPerTable(str_subscriber, subscriptionId, tablename);
                });
        }

        protected void EnableIndexesPerTable(string str_subscriber, int subscriptionId, string table)
        {
            SqlConnection conn_subscriber = new SqlConnection(str_subscriber);

            try
            {
                conn_subscriber.Open();
                SqlCommand cmd = new SqlCommand(@"rpl.spEnableIndexes", conn_subscriber);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter param_subscriptionId = new SqlParameter("@subscriptionId", SqlDbType.Int);
                param_subscriptionId.Value = subscriptionId;
                param_subscriptionId.Direction = ParameterDirection.Input;
                cmd.Parameters.Add(param_subscriptionId);

                SqlParameter param_tablename = new SqlParameter("@tablename", SqlDbType.VarChar, 100);
                param_tablename.Value = table;
                param_tablename.Direction = ParameterDirection.Input;
                cmd.Parameters.Add(param_tablename);

                cmd.CommandTimeout = 2400;
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                varsuccess = false;
                shortMessage += "/ Error enabling indexes for " + table;
                detailMessage.AppendLine(table + "-" + ex.Message);
                throw;
            }
            finally
            {
                conn_subscriber.Close();
            }
        }
        protected string ReturnGetProcName(string str_subscriber, string table, int subscriptionId)
        {
            SqlConnection conn_subscriber = new SqlConnection(str_subscriber);
            String proc = string.Empty;
            try
            {
                conn_subscriber.Open();
                SqlCommand cmd = new SqlCommand(@"rpl.spReturnGetProcName", conn_subscriber);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                SqlParameter param_subscriptionId = new SqlParameter("@SubscriptionId", SqlDbType.Int);
                param_subscriptionId.Value = subscriptionId;
                param_subscriptionId.Direction = ParameterDirection.Input;
                cmd.Parameters.Add(param_subscriptionId);

                SqlParameter param_table = new SqlParameter("@Table", SqlDbType.VarChar, 200);
                param_table.Value = table;
                param_table.Direction = ParameterDirection.Input;
                cmd.Parameters.Add(param_table);

                SqlParameter param_RvTotalRows = new SqlParameter("@GetProc", SqlDbType.VarChar, 200);
                param_RvTotalRows.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(param_RvTotalRows);

                cmd.ExecuteNonQuery();
                proc = cmd.Parameters["@GetProc"].Value.ToString();
            }
            catch (Exception ex)
            {
                varsuccess = false;
                shortMessage += "/ Error returning proc name for " + table;
                detailMessage.AppendLine(table + "-" + ex.Message);
                throw;
            }
            finally
            {
                conn_subscriber.Close();
            }
            return (proc);
        }

        protected void CopyToStageTable(string str_publisher, string str_subscriber, string rvfrom, string rvto, string table, int subscriptionId, int batchSize, string mergeIdentifier)
        {
            string table_clean = table.Replace(".", "_").Replace("[", "").Replace("]", "").Replace("#Initialize", "");
            string target_table = "rpl.stg_" + table_clean;
            string get_proc = ReturnGetProcName(str_subscriber, table_clean, subscriptionId); // "rpl.spGet_" + table_clean;
            Boolean local_useStage = useStage;

            if ((rvfrom == "0x") && (string.IsNullOrEmpty(mergeIdentifier)))
            {
                target_table = table.Replace("#Initialize", "");
            }
            else if (table.Contains("#Initialize"))
            {
                rvfrom = "0x";//get all rows from published table to be merged into prod
                table = table.Replace("#Initialize", "");
                target_table = table;
                local_useStage = false;
                CleanProdTables(str_subscriber, subscriptionId, target_table); //clean up table in prod
            }

            SqlConnection conn_publisher = new SqlConnection(str_publisher);
            try
            {
                conn_publisher.Open();

                SqlCommand cmdGetProc = new SqlCommand(get_proc, conn_publisher);
                cmdGetProc.CommandType = CommandType.StoredProcedure;
                cmdGetProc.CommandTimeout = 12000;

                SqlParameter param_rvfrom = new SqlParameter("@rvfrom", SqlDbType.VarChar, 20);
                param_rvfrom.Direction = ParameterDirection.Input;
                param_rvfrom.Value = rvfrom;
                cmdGetProc.Parameters.Add(param_rvfrom);

                SqlParameter param_rvto = new SqlParameter("@rvto", SqlDbType.VarChar, 20);
                param_rvto.Direction = ParameterDirection.Input;
                param_rvto.Value = rvto;
                cmdGetProc.Parameters.Add(param_rvto);

                if (!(String.IsNullOrEmpty(mergeIdentifier)) && mergeIdentifier.ToLower() != "distdb")
                {
                    SqlParameter param_mergeIdentifier = new SqlParameter("@ExcludeMergeIdentifier", SqlDbType.VarChar, 50);
                    param_mergeIdentifier.Direction = ParameterDirection.Input;
                    param_mergeIdentifier.Value = mergeIdentifier;
                    cmdGetProc.Parameters.Add(param_mergeIdentifier);
                }

                using (SqlBulkCopy bulk = new SqlBulkCopy(str_subscriber, SqlBulkCopyOptions.TableLock | SqlBulkCopyOptions.KeepNulls | SqlBulkCopyOptions.KeepIdentity))
                {
                    bulk.DestinationTableName = target_table;
                    bulk.BatchSize = batchSize;
                    bulk.BulkCopyTimeout = 360;
                    bulk.EnableStreaming = true;

                    SqlDataReader reader = cmdGetProc.ExecuteReader();
                    List<string> listColumns = GetColumnList(str_subscriber, table, local_useStage, subscriptionId);
                    foreach (string col in listColumns)
                    {
                        bulk.ColumnMappings.Add(col, col);
                    }
                    LogTable(str_subscriber, table, subscriptionId, reader.RecordsAffected);
                    bulk.WriteToServer(reader);
                }
            }
            catch (Exception ex)
            {
                varsuccess = false;
                shortMessage += "/ Error copying table " + table;
                detailMessage.AppendLine(table + "-" + ex.Message);
                throw; // if a table fails to copy then we abort all others
            }
            finally
            {
                conn_publisher.Close();
            }
        }

        protected void LogTable(string str_subscriber, string table, int subscriptionId, int rows)
        {
            SqlConnection conn_subscriber = new SqlConnection(str_subscriber);
            try
            {
                conn_subscriber.Open();

                SqlCommand cmd = new SqlCommand(@"rpl.spLogTable", conn_subscriber);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter param_subscriptionId = new SqlParameter("@subscriptionId", SqlDbType.Int);
                param_subscriptionId.Value = subscriptionId;
                param_subscriptionId.Direction = ParameterDirection.Input;
                cmd.Parameters.Add(param_subscriptionId);

                SqlParameter param_rows = new SqlParameter("@rows", SqlDbType.BigInt);
                param_rows.Value = rows;
                param_rows.Direction = ParameterDirection.Input;
                cmd.Parameters.Add(param_rows);

                SqlParameter param_table = new SqlParameter("@table", SqlDbType.VarChar, 100);
                param_table.Value = table;
                param_table.Direction = ParameterDirection.Input;
                cmd.Parameters.Add(param_table);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                varsuccess = false;
                shortMessage += "/ Error logging table " + table;
                detailMessage.AppendLine(table + "-" + ex.Message);
                throw;
            }
            finally
            {
                conn_subscriber.Close();
            }
        }

        protected void MergeTable(string str_subscriber, string table)
        {
            string merge_proc = "rpl.spMerge_" + table.Replace(".", "_").Replace("[", "").Replace("]", "").Replace("#Initialize", "");

            SqlConnection conn_subscriber = new SqlConnection(str_subscriber);
            try
            {
                conn_subscriber.Open();
                // merge
                SqlCommand cmd_merge = new SqlCommand(merge_proc, conn_subscriber);
                cmd_merge.CommandType = CommandType.StoredProcedure;
                cmd_merge.CommandTimeout = 10800; //3 hours
                cmd_merge.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                varsuccess = false;
                shortMessage += "/ Error merging table " + table;
                detailMessage.AppendLine(table + "-" + ex.Message);
                throw;
            }
            finally
            {
                conn_subscriber.Close();
            }
        }

        protected List<string> GetColumnList(string str_subscriber, string table, bool useStage, int subscriptionId)
        {
            SqlConnection conn_subscriber = new SqlConnection(str_subscriber);
            List<string> list = new List<string>();
            try
            {
                conn_subscriber.Open();
                SqlDataAdapter adapter = new SqlDataAdapter();
                DataSet ds = new DataSet();
                string sql = "exec rpl.spGetColumnList @SubscriptionId = " + subscriptionId.ToString() + ", @TableName ='" + table + "', @UseStage = " + Convert.ToInt32(useStage).ToString();
                SqlCommand cmd = new SqlCommand(sql, conn_subscriber);
                cmd.CommandType = CommandType.Text;
                adapter.SelectCommand = cmd;
                adapter.Fill(ds);

                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    list.Add(Convert.ToString(dr["ColumnName"]));
                }
            }
            catch (Exception ex)
            {
                varsuccess = false;
                shortMessage += "/ Error getting column list for " + table;
                detailMessage.AppendLine(table + "-" + ex.Message);
                throw;
            }
            finally
            {
                conn_subscriber.Dispose();
            }
            return (list);
        }

        protected string GetLastSuccessfullRv(string str_subscriber, int subscriptionId)
        {
            SqlConnection conn_subscriber = new SqlConnection(str_subscriber);
            string rv = string.Empty;
            try
            {
                conn_subscriber.Open();

                SqlCommand cmd = new SqlCommand(@"rpl.spGetLastSuccessfullRv", conn_subscriber);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter param_subscriptionId = new SqlParameter("@subscriptionId", SqlDbType.Int);
                param_subscriptionId.Value = subscriptionId;
                param_subscriptionId.Direction = ParameterDirection.Input;
                cmd.Parameters.Add(param_subscriptionId);

                SqlParameter param_rv = new SqlParameter("@rv", SqlDbType.VarChar, 20);
                param_rv.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(param_rv);

                cmd.ExecuteNonQuery();
                rv = cmd.Parameters["@rv"].Value.ToString();
            }
            catch (Exception ex)
            {
                varsuccess = false;
                shortMessage += "/ Error getting last successful rv ";
                detailMessage.AppendLine("-" + ex.Message);
                throw;
            }
            finally
            {
                conn_subscriber.Dispose();
            }

            return (rv);
        }

        protected void CleanProdTables(string str_subscriber, int subscriptionId, string table)
        {
            SqlConnection conn_subscriber = new SqlConnection(str_subscriber);
            try
            {
                conn_subscriber.Open();

                SqlCommand cmd = new SqlCommand(@"rpl.spCleanProdTables", conn_subscriber);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter param_subscriptionId = new SqlParameter("@SubscriptionId", SqlDbType.Int);
                param_subscriptionId.Value = subscriptionId;
                param_subscriptionId.Direction = ParameterDirection.Input;
                cmd.Parameters.Add(param_subscriptionId);

                SqlParameter param_table = new SqlParameter("@Table", SqlDbType.VarChar, 200);
                param_table.Value = table;
                param_table.Direction = ParameterDirection.Input;
                cmd.Parameters.Add(param_table);
                cmd.CommandTimeout = 1800;
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                varsuccess = false;
                shortMessage += "/ Error cleaning prod data for " + table;
                detailMessage.AppendLine("-" + ex.Message);
                throw;
            }
            finally
            {
                conn_subscriber.Dispose();
            }
        }

    }
}
